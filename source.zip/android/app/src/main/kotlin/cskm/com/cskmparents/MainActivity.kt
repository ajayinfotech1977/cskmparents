package cskm.com.cskmparents

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
